package interfaces;

/**
 *
 * @author yvan
 */
public interface Mesurable {
    int mesure();
}
