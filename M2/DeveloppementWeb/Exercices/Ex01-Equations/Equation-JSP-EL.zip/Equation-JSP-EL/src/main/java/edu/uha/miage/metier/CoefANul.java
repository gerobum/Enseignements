
package edu.uha.miage.metier;

/**
 *
 * @author yvan
 */
public class CoefANul extends Exception {
    
}
